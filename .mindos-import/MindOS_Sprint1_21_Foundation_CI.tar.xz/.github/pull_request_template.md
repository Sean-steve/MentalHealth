## MindOS Pull Request & Governance Gate

### 1. Summary
<!-- Concise summary of proposed changes -->

### 2. Why
<!-- Business, clinical, regulatory, or technical rationale -->

### 3. Domains Affected
- [ ] Safety Kernel (`mindos/safety`)
- [ ] Clinical Governance (`mindos/clinical_governance`)
- [ ] Privacy & Data Protection (`mindos/privacy_governance`)
- [ ] Regulatory Compliance (`mindos/regulatory_governance` / Kenya DHA)
- [ ] AI Safety & Companion (`mindos/ai_safety_governance`, `mindos/ai`)
- [ ] Platform & Database (`mindos/platform`)
- [ ] User Experience & Frontend (`src/`)

### 4. Database Impact
- [ ] No schema modification
- [ ] New backward-compatible migration (Expand phase)
- [ ] Column/Table deprecation (Contract phase)
- [ ] Migration Safety Analyzer validated (0 critical/high destructive operations)

### 5. API Impact
- [ ] No API contract changes
- [ ] Backward-compatible endpoint additions
- [ ] Breaking API changes (ADR required)

### 6. Security & Privacy Impact
- [ ] Six-tier Data Classification enforced (ADR-004)
- [ ] Zero-Trust Authorization evaluated (ADR-002)
- [ ] Cryptographic Audit Ledger entry added (ADR-001)
- [ ] No unredacted PII or clinical narrative in logs
- [ ] Secret scanning verified (`npm run scan:secrets`)

### 7. Clinical & Safety Invariant Impact
- [ ] No direct modification to Safety Kernel deterministic policy
- [ ] Verified Crisis Directory unexpired contacts preserved (R-SAFE-002)
- [ ] Emergency Kill Switch preserved or updated (R-SAFE-KILL-SWITCH)

### 8. Testing & Validation
- [ ] Unit tests added / updated
- [ ] Integration tests passing
- [ ] E2E smoke tests passing
- [ ] All 6 Engineering Quality Gates passing (`npm run verify`)

### 9. Screenshots / Verification Evidence (if UI)
<!-- Attach screenshots or diagnostic CLI outputs -->

### 10. Migration & Deployment Notes
<!-- Deployment sequence or rollback considerations -->

### 11. Governance Required?
**GOVERNANCE REQUIRED:** [ ] YES  /  [ ] NO  /  [ ] UNKNOWN

*If YES, this pull request requires multi-signoff from Clinical Safety and Regulatory Officers prior to staging/production merge.*
