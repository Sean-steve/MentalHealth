/**
 * MindOS Care Plans Domain Invariants & Governance Rules
 * Authority: Master Architecture Index Section 7 & 14, Volumes I, III, XV & Appendices B / C / Q
 * Clinical Safety Policy Catalogue (R-PLAN-001..007, ADR-040..044)
 */

import { DomainInvariantError, AuthorizationError } from '../../platform/errors/index.js';
import {
  CarePlan,
  CarePlanVersion,
  CareGoal
} from './entities.js';
import {
  CarePlanState,
  CarePlanVersionStatus,
  CareGoalProvenance
} from './types.js';

export class CarePlanInvariants {
  /**
   * Asserts care relationship exists and is active.
   */
  public static assertRelationshipEligible(relationship: {
    id: string;
    status: string;
    primary_provider_id?: string;
  }): void {
    if (relationship.status !== 'ACTIVE') {
      throw new DomainInvariantError(
        `R-PLAN-001: Cannot author or mutate Care Plan under inactive CareRelationship ${relationship.id} (status: ${relationship.status}).`,
        { safeUserMessage: 'An active care relationship is required for care planning.' }
      );
    }
  }

  /**
   * Enforces immutability of active plan versions.
   */
  public static assertVersionEditable(version: CarePlanVersion): void {
    if (version.status === CarePlanVersionStatus.ACTIVE || version.status === CarePlanVersionStatus.SUPERSEDED) {
      throw new DomainInvariantError(
        `R-PLAN-003: CarePlanVersion ${version.id} (version ${version.version}) is in ${version.status} state and cannot be mutated in-place. A new plan version must be drafted.`,
        { safeUserMessage: 'Active care plan versions are immutable. Please create a new plan version.' }
      );
    }
  }

  /**
   * Validates AI-suggested goal workflow: AI goals cannot be activated without human clinician review.
   */
  public static assertGoalActivationProvenance(goal: CareGoal, actorRole: string): void {
    if (goal.provenance === CareGoalProvenance.AI_SUGGESTED && actorRole !== 'PROFESSIONAL' && actorRole !== 'CLINICAL_REVIEWER') {
      throw new AuthorizationError(
        `R-PLAN-005: AI-suggested care goal ${goal.id} requires human clinical professional review before activation.`,
        { errorCode: 'AUTHZ_003' }
      );
    }
  }

  /**
   * Asserts plan is in active state for clinical execution.
   */
  public static assertPlanActive(plan: CarePlan, operation = 'clinical task execution'): void {
    if (plan.status !== CarePlanState.ACTIVE) {
      throw new DomainInvariantError(
        `R-PLAN-006: Care Plan ${plan.id} is in status ${plan.status}. Active care plan required for ${operation}.`,
        { safeUserMessage: `Care plan is currently ${plan.status.toLowerCase()}.` }
      );
    }
  }
}
