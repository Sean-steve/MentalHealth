/**
 * MindOS In-Memory Care Plan Repository
 * Authority: Master Architecture Index Section 7 & 14, Volumes I, III, XV
 */

import { ICarePlanRepository } from './interfaces.js';
import {
  CarePlan,
  CarePlanVersion,
  CareGoal,
  CareGoalReview,
  CareIntervention,
  CarePlanReview,
  ContentAssignment,
  AssessmentAssignment
} from '../domain/entities.js';
import { CarePlanState, CareGoalStatus, CarePlanVersionStatus } from '../domain/types.js';

export class InMemoryCarePlanRepository implements ICarePlanRepository {
  private plans: Map<string, CarePlan> = new Map();
  private versions: Map<string, CarePlanVersion> = new Map();
  private goals: Map<string, CareGoal> = new Map();
  private goalReviews: Map<string, CareGoalReview[]> = new Map();
  private interventions: Map<string, CareIntervention> = new Map();
  private planReviews: Map<string, CarePlanReview> = new Map();
  private contentAssignments: Map<string, ContentAssignment> = new Map();
  private assessmentAssignments: Map<string, AssessmentAssignment> = new Map();

  public async savePlan(plan: CarePlan): Promise<void> {
    this.plans.set(plan.id, { ...plan });
  }

  public async findPlanById(id: string): Promise<CarePlan | null> {
    const p = this.plans.get(id);
    return p ? { ...p } : null;
  }

  public async findPlanByRelationshipId(relationshipId: string): Promise<CarePlan | null> {
    for (const p of this.plans.values()) {
      if (p.care_relationship_id === relationshipId) {
        return { ...p };
      }
    }
    return null;
  }

  public async findPlansByUserId(userId: string, status?: CarePlanState): Promise<CarePlan[]> {
    const results: CarePlan[] = [];
    for (const p of this.plans.values()) {
      if (p.subject_user_id === userId) {
        if (!status || p.status === status) {
          results.push({ ...p });
        }
      }
    }
    return results;
  }

  public async findPlansByProfessionalId(professionalId: string, status?: CarePlanState): Promise<CarePlan[]> {
    const results: CarePlan[] = [];
    for (const p of this.plans.values()) {
      if (p.primary_professional_id === professionalId) {
        if (!status || p.status === status) {
          results.push({ ...p });
        }
      }
    }
    return results;
  }

  public async saveVersion(version: CarePlanVersion): Promise<void> {
    this.versions.set(version.id, { ...version });
  }

  public async findVersionById(id: string): Promise<CarePlanVersion | null> {
    const v = this.versions.get(id);
    return v ? { ...v } : null;
  }

  public async findVersionsByPlanId(planId: string): Promise<CarePlanVersion[]> {
    const results: CarePlanVersion[] = [];
    for (const v of this.versions.values()) {
      if (v.care_plan_id === planId) {
        results.push({ ...v });
      }
    }
    return results.sort((a, b) => a.version - b.version);
  }

  public async findActiveVersion(planId: string): Promise<CarePlanVersion | null> {
    for (const v of this.versions.values()) {
      if (v.care_plan_id === planId && v.status === CarePlanVersionStatus.ACTIVE) {
        return { ...v };
      }
    }
    return null;
  }

  public async saveGoal(goal: CareGoal): Promise<void> {
    this.goals.set(goal.id, { ...goal });
  }

  public async findGoalById(id: string): Promise<CareGoal | null> {
    const g = this.goals.get(id);
    return g ? { ...g } : null;
  }

  public async findGoalsByVersionId(versionId: string, status?: CareGoalStatus): Promise<CareGoal[]> {
    const results: CareGoal[] = [];
    for (const g of this.goals.values()) {
      if (g.care_plan_version_id === versionId) {
        if (!status || g.status === status) {
          results.push({ ...g });
        }
      }
    }
    return results;
  }

  public async saveGoalReview(review: CareGoalReview): Promise<void> {
    const list = this.goalReviews.get(review.goal_id) || [];
    list.push({ ...review });
    this.goalReviews.set(review.goal_id, list);
  }

  public async findGoalReviews(goalId: string): Promise<CareGoalReview[]> {
    const list = this.goalReviews.get(goalId) || [];
    return list.map(r => ({ ...r }));
  }

  public async saveIntervention(intervention: CareIntervention): Promise<void> {
    this.interventions.set(intervention.id, { ...intervention });
  }

  public async findInterventionById(id: string): Promise<CareIntervention | null> {
    const i = this.interventions.get(id);
    return i ? { ...i } : null;
  }

  public async findInterventionsByVersionId(versionId: string): Promise<CareIntervention[]> {
    const results: CareIntervention[] = [];
    for (const i of this.interventions.values()) {
      if (i.care_plan_version_id === versionId) {
        results.push({ ...i });
      }
    }
    return results;
  }

  public async savePlanReview(review: CarePlanReview): Promise<void> {
    this.planReviews.set(review.id, { ...review });
  }

  public async findPlanReviewById(id: string): Promise<CarePlanReview | null> {
    const r = this.planReviews.get(id);
    return r ? { ...r } : null;
  }

  public async findPlanReviewsByPlanId(planId: string): Promise<CarePlanReview[]> {
    const results: CarePlanReview[] = [];
    for (const r of this.planReviews.values()) {
      if (r.care_plan_id === planId) {
        results.push({ ...r });
      }
    }
    return results.sort((a, b) => new Date(a.scheduled_for).getTime() - new Date(b.scheduled_for).getTime());
  }

  public async saveContentAssignment(assignment: ContentAssignment): Promise<void> {
    this.contentAssignments.set(assignment.id, { ...assignment });
  }

  public async findContentAssignmentById(id: string): Promise<ContentAssignment | null> {
    const a = this.contentAssignments.get(id);
    return a ? { ...a } : null;
  }

  public async findContentAssignmentsByPlanId(planId: string): Promise<ContentAssignment[]> {
    const results: ContentAssignment[] = [];
    for (const a of this.contentAssignments.values()) {
      if (a.care_plan_id === planId) {
        results.push({ ...a });
      }
    }
    return results;
  }

  public async saveAssessmentAssignment(assignment: AssessmentAssignment): Promise<void> {
    this.assessmentAssignments.set(assignment.id, { ...assignment });
  }

  public async findAssessmentAssignmentById(id: string): Promise<AssessmentAssignment | null> {
    const a = this.assessmentAssignments.get(id);
    return a ? { ...a } : null;
  }

  public async findAssessmentAssignmentsByPlanId(planId: string): Promise<AssessmentAssignment[]> {
    const results: AssessmentAssignment[] = [];
    for (const a of this.assessmentAssignments.values()) {
      if (a.care_plan_id === planId) {
        results.push({ ...a });
      }
    }
    return results;
  }

  public async clear(): Promise<void> {
    this.plans.clear();
    this.versions.clear();
    this.goals.clear();
    this.goalReviews.clear();
    this.interventions.clear();
    this.planReviews.clear();
    this.contentAssignments.clear();
    this.assessmentAssignments.clear();
  }
}
