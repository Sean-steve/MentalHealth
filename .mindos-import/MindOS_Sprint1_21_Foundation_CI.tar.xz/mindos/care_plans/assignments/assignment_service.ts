/**
 * MindOS Content & Assessment Assignment Service
 * Authority: Master Architecture Index Section 7 & 14, Volumes I, III, XV & Appendices B / C / Q
 * 
 * Rules:
 * - Content assignments pin approved ContentDefinition/ContentVersion.
 * - Assessment assignments pin validated instrument, clinical purpose, and due window.
 */

import { generateUUIDv7 } from '../../platform/database/uuid.js';
import { EventBus } from '../../platform/events/index.js';
import { AuditService } from '../../platform/audit/index.js';
import { DataClassification } from '../../platform/shared/data_classification.js';
import { NotFoundError, DomainInvariantError } from '../../platform/errors/index.js';
import { ContentAssignment, AssessmentAssignment } from '../domain/entities.js';
import { ICarePlanRepository } from '../repositories/interfaces.js';
import { CarePlanService } from '../plans/care_plan_service.js';
import { ContentApplicationService } from '../../content/index.js';
import { AssessmentRegistry } from '../../assessments/index.js';

export interface AssignContentParams {
  planId: string;
  interventionId?: string;
  contentId: string;
  contentVersion: number;
  assignedBy: string;
  dueDate?: string;
}

export interface AssignAssessmentParams {
  planId: string;
  interventionId?: string;
  instrumentType: string;
  instrumentVersion?: number;
  assignmentPurpose: string;
  dueWindow: {
    startDate: string;
    endDate: string;
  };
  assignedBy: string;
}

export class AssignmentService {
  private static repository: ICarePlanRepository;

  public static setRepository(repo: ICarePlanRepository): void {
    AssignmentService.repository = repo;
  }

  public static async assignContent(params: AssignContentParams): Promise<ContentAssignment> {
    const plan = await CarePlanService.getPlan(params.planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${params.planId} not found.`);
    }

    // Verify content exists and is published/active in ContentApplicationService if accessible
    try {
      const content = ContentApplicationService.getContentDetail(params.contentId);
      if (content && ((content as any).status === 'SUSPENDED' || (content as any).status === 'RETIRED')) {
        throw new DomainInvariantError(
          `Cannot assign content ${params.contentId} because it is in ${(content as any).status} status.`
        );
      }
    } catch (err: unknown) {
      if (err instanceof DomainInvariantError) throw err;
      // If content lookup fails closed, verify not hard blocked
    }

    const assignmentId = generateUUIDv7();
    const assignment: ContentAssignment = {
      id: assignmentId,
      care_plan_id: plan.id,
      care_plan_version_id: plan.current_version_id,
      intervention_id: params.interventionId,
      subject_user_id: plan.subject_user_id,
      assigned_by: params.assignedBy,
      content_id: params.contentId,
      content_version: params.contentVersion,
      status: 'ASSIGNED',
      due_date: params.dueDate,
      created_at: new Date().toISOString()
    };

    await AssignmentService.repository.saveContentAssignment(assignment);

    EventBus.enqueue(
      'care.assignment_created',
      'care_plans',
      assignmentId,
      DataClassification.RESTRICTED,
      {
        assignment_id: assignmentId,
        plan_id: plan.id,
        assignment_type: 'CONTENT',
        resource_id: params.contentId,
        assigned_by: params.assignedBy
      }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: params.assignedBy,
      action: 'CARE_ASSIGNMENT.CONTENT_ASSIGNED',
      resource_type: 'content_assignment',
      resource_id: assignmentId,
      purpose: 'Psychoeducational Content Prescription',
      authorization_basis: { planId: plan.id },
      result: 'ALLOWED',
      metadata: { contentId: params.contentId, contentVersion: params.contentVersion }
    });

    return assignment;
  }

  public static async assignAssessment(params: AssignAssessmentParams): Promise<AssessmentAssignment> {
    const plan = await CarePlanService.getPlan(params.planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${params.planId} not found.`);
    }

    const assignmentId = generateUUIDv7();
    const assignment: AssessmentAssignment = {
      id: assignmentId,
      care_plan_id: plan.id,
      care_plan_version_id: plan.current_version_id,
      intervention_id: params.interventionId,
      subject_user_id: plan.subject_user_id,
      assigned_by: params.assignedBy,
      instrument_type: params.instrumentType,
      instrument_version: params.instrumentVersion,
      assignment_purpose: params.assignmentPurpose,
      due_window: {
        start_date: params.dueWindow.startDate,
        end_date: params.dueWindow.endDate
      },
      status: 'PENDING',
      created_at: new Date().toISOString()
    };

    await AssignmentService.repository.saveAssessmentAssignment(assignment);

    EventBus.enqueue(
      'care.assignment_created',
      'care_plans',
      assignmentId,
      DataClassification.RESTRICTED,
      {
        assignment_id: assignmentId,
        plan_id: plan.id,
        assignment_type: 'ASSESSMENT',
        instrument_type: params.instrumentType,
        assigned_by: params.assignedBy
      }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: params.assignedBy,
      action: 'CARE_ASSIGNMENT.ASSESSMENT_ASSIGNED',
      resource_type: 'assessment_assignment',
      resource_id: assignmentId,
      purpose: params.assignmentPurpose,
      authorization_basis: { planId: plan.id },
      result: 'ALLOWED',
      metadata: { instrumentType: params.instrumentType, dueWindow: params.dueWindow }
    });

    return assignment;
  }

  public static async listAssignmentsForPlan(planId: string): Promise<{
    content: ContentAssignment[];
    assessments: AssessmentAssignment[];
  }> {
    const content = await AssignmentService.repository.findContentAssignmentsByPlanId(planId);
    const assessments = await AssignmentService.repository.findAssessmentAssignmentsByPlanId(planId);
    return { content, assessments };
  }
}
