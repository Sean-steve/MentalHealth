/**
 * MindOS Care Plan Lifecycle Management Service
 * Authority: Master Architecture Index Section 7 & 14, Volumes I, III, XV & Appendices B / C / Q
 * 
 * Rules:
 * - Active CarePlanVersion is permanently immutable. Material modifications create Version N+1.
 * - Care plan requires an active Care Relationship and verified professional author.
 */

import { generateUUIDv7 } from '../../platform/database/uuid.js';
import { EventBus } from '../../platform/events/index.js';
import { AuditService } from '../../platform/audit/index.js';
import { DataClassification } from '../../platform/shared/data_classification.js';
import { DomainInvariantError, AuthorizationError, NotFoundError } from '../../platform/errors/index.js';
import { validateStateTransition } from '../../platform/shared/state_machines.js';
import {
  CarePlan,
  CarePlanVersion,
  CareGoal,
  CareIntervention
} from '../domain/entities.js';
import {
  CarePlanType,
  CarePlanState,
  CarePlanVersionStatus
} from '../domain/types.js';
import { CarePlanInvariants } from '../domain/invariants.js';
import { ICarePlanRepository } from '../repositories/interfaces.js';
import { CarePlanEligibilityService } from '../application/eligibility_service.js';
import {
  RelationshipAccessEvaluator,
  CareRelationshipService,
  DataDomain,
  ActionPermission,
  CareRelationshipState
} from '../../care_relationships/index.js';

export interface CreateDraftPlanParams {
  relationshipId: string;
  authorProfessionalId: string;
  planType: CarePlanType;
  summary: string;
  goals?: CareGoal[];
  interventions?: CareIntervention[];
  reviewFrequencyDays?: number;
  requiresUserAcknowledgement?: boolean;
  actorId: string;
}

export interface CreateNewVersionParams {
  planId: string;
  authorProfessionalId: string;
  summary: string;
  goals: CareGoal[];
  interventions: CareIntervention[];
  changeRationale: string;
  reviewFrequencyDays?: number;
  actorId: string;
}

export class CarePlanService {
  private static repository: ICarePlanRepository;

  public static setRepository(repo: ICarePlanRepository): void {
    CarePlanService.repository = repo;
  }

  public static getRepository(): ICarePlanRepository {
    return CarePlanService.repository;
  }

  public static async createDraftPlan(params: CreateDraftPlanParams): Promise<CarePlan> {
    // 1. Eligibility evaluation
    const eligibility = await CarePlanEligibilityService.evaluate({
      relationshipId: params.relationshipId,
      professionalId: params.authorProfessionalId,
      planType: params.planType
    });

    if (!eligibility.isEligible) {
      throw new DomainInvariantError(
        `Care Plan creation ineligible: ${eligibility.blockers.join(' ')}`,
        { safeUserMessage: 'Care plan cannot be created due to unmet eligibility requirements.' }
      );
    }

    // 2. Authorize via RelationshipAccessEvaluator
    await RelationshipAccessEvaluator.assertAccess({
      relationshipId: params.relationshipId,
      professionalId: params.authorProfessionalId,
      dataDomain: DataDomain.CARE_PLANS,
      action: ActionPermission.WRITE,
      purpose: 'CARE_DELIVERY'
    });

    const rel = await CareRelationshipService.getRelationship(params.relationshipId);
    if (!rel) {
      throw new NotFoundError(`CareRelationship ${params.relationshipId} not found.`);
    }

    const planId = generateUUIDv7();
    const versionId = generateUUIDv7();
    const now = new Date().toISOString();
    const reviewFreq = params.reviewFrequencyDays || 30;
    const nextReview = new Date(Date.now() + 3600000 * 24 * reviewFreq).toISOString();

    const version: CarePlanVersion = {
      id: versionId,
      care_plan_id: planId,
      version: 1,
      status: CarePlanVersionStatus.DRAFT,
      summary: params.summary,
      goals: params.goals || [],
      interventions: params.interventions || [],
      review_schedule: {
        frequency_days: reviewFreq,
        next_review_due: nextReview
      },
      effective_from: now,
      authored_by: params.authorProfessionalId,
      created_at: now
    };

    const initialStatus = params.requiresUserAcknowledgement
      ? CarePlanState.PENDING_USER_ACKNOWLEDGEMENT
      : CarePlanState.DRAFT;

    const plan: CarePlan = {
      id: planId,
      subject_user_id: rel.subject_user_id,
      care_relationship_id: params.relationshipId,
      primary_professional_id: params.authorProfessionalId,
      plan_type: params.planType,
      status: initialStatus,
      current_version_id: versionId,
      started_at: now,
      created_at: now,
      updated_at: now,
      version: 1
    };

    await CarePlanService.repository.saveVersion(version);
    await CarePlanService.repository.savePlan(plan);

    // Save initial goals and interventions in repository
    if (params.goals) {
      for (const g of params.goals) {
        g.care_plan_version_id = versionId;
        await CarePlanService.repository.saveGoal(g);
      }
    }
    if (params.interventions) {
      for (const i of params.interventions) {
        i.care_plan_version_id = versionId;
        await CarePlanService.repository.saveIntervention(i);
      }
    }

    EventBus.enqueue(
      'care.plan_created',
      'care_plans',
      planId,
      DataClassification.RESTRICTED,
      {
        plan_id: planId,
        relationship_id: params.relationshipId,
        author_id: params.authorProfessionalId,
        status: initialStatus,
        version: 1
      }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: params.actorId,
      action: 'CARE_PLAN.DRAFT_CREATED',
      resource_type: 'care_plan',
      resource_id: planId,
      purpose: 'Care Plan Formulation',
      authorization_basis: { relationshipId: params.relationshipId },
      result: 'ALLOWED',
      metadata: {
        planType: params.planType,
        version: 1,
        goalsCount: (params.goals || []).length
      }
    });

    return plan;
  }

  public static async activatePlan(planId: string, actorId: string): Promise<CarePlan> {
    const plan = await CarePlanService.repository.findPlanById(planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${planId} not found.`);
    }

    validateStateTransition('CarePlanState', plan.status, CarePlanState.ACTIVE, plan.id, actorId);

    const version = await CarePlanService.repository.findVersionById(plan.current_version_id);
    if (!version) {
      throw new NotFoundError(`CarePlanVersion ${plan.current_version_id} not found.`);
    }

    const now = new Date().toISOString();
    version.status = CarePlanVersionStatus.ACTIVE;
    version.approved_by = actorId;
    await CarePlanService.repository.saveVersion(version);

    plan.status = CarePlanState.ACTIVE;
    plan.updated_at = now;
    plan.version += 1;
    await CarePlanService.repository.savePlan(plan);

    EventBus.enqueue(
      'care.plan_activated',
      'care_plans',
      plan.id,
      DataClassification.RESTRICTED,
      {
        plan_id: plan.id,
        version_id: version.id,
        activated_by: actorId,
        activated_at: now
      }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: actorId,
      action: 'CARE_PLAN.ACTIVATED',
      resource_type: 'care_plan',
      resource_id: plan.id,
      purpose: 'Care Strategy Activation',
      authorization_basis: { relationshipId: plan.care_relationship_id },
      result: 'ALLOWED',
      metadata: { version: version.version }
    });

    return plan;
  }

  public static async userAcknowledgePlan(planId: string, userId: string): Promise<CarePlan> {
    const plan = await CarePlanService.repository.findPlanById(planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${planId} not found.`);
    }

    if (plan.subject_user_id !== userId) {
      throw new AuthorizationError('Only the data subject user may acknowledge their care plan.', {
        errorCode: 'AUTHZ_003'
      });
    }

    const version = await CarePlanService.repository.findVersionById(plan.current_version_id);
    if (!version) {
      throw new NotFoundError(`CarePlanVersion ${plan.current_version_id} not found.`);
    }

    const now = new Date().toISOString();
    version.acknowledged_by_user = true;
    version.acknowledged_at = now;
    await CarePlanService.repository.saveVersion(version);

    if (plan.status === CarePlanState.PENDING_USER_ACKNOWLEDGEMENT) {
      validateStateTransition('CarePlanState', plan.status, CarePlanState.ACTIVE, plan.id, userId);
      plan.status = CarePlanState.ACTIVE;
      version.status = CarePlanVersionStatus.ACTIVE;
      await CarePlanService.repository.saveVersion(version);
    }

    plan.updated_at = now;
    plan.version += 1;
    await CarePlanService.repository.savePlan(plan);

    AuditService.record({
      actor_type: 'USER',
      actor_id: userId,
      action: 'CARE_PLAN.USER_ACKNOWLEDGED',
      resource_type: 'care_plan',
      resource_id: plan.id,
      purpose: 'Patient Treatment Engagement',
      authorization_basis: { planId: plan.id },
      result: 'ALLOWED',
      metadata: { acknowledgedAt: now }
    });

    return plan;
  }

  public static async createNewVersion(params: CreateNewVersionParams): Promise<CarePlanVersion> {
    const plan = await CarePlanService.repository.findPlanById(params.planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${params.planId} not found.`);
    }

    // Authorize WRITE
    await RelationshipAccessEvaluator.assertAccess({
      relationshipId: plan.care_relationship_id,
      professionalId: params.authorProfessionalId,
      dataDomain: DataDomain.CARE_PLANS,
      action: ActionPermission.WRITE,
      purpose: 'CARE_DELIVERY'
    });

    const activeVersion = await CarePlanService.repository.findVersionById(plan.current_version_id);
    const newVersionNumber = activeVersion ? activeVersion.version + 1 : 2;

    const newVersionId = generateUUIDv7();
    const now = new Date().toISOString();
    const reviewFreq = params.reviewFrequencyDays || activeVersion?.review_schedule.frequency_days || 30;
    const nextReview = new Date(Date.now() + 3600000 * 24 * reviewFreq).toISOString();

    // Mark previous active version as SUPERSEDED
    if (activeVersion && activeVersion.status === CarePlanVersionStatus.ACTIVE) {
      activeVersion.status = CarePlanVersionStatus.SUPERSEDED;
      activeVersion.effective_until = now;
      await CarePlanService.repository.saveVersion(activeVersion);
    }

    const newVersion: CarePlanVersion = {
      id: newVersionId,
      care_plan_id: plan.id,
      version: newVersionNumber,
      status: CarePlanVersionStatus.ACTIVE,
      summary: params.summary,
      goals: params.goals,
      interventions: params.interventions,
      review_schedule: {
        frequency_days: reviewFreq,
        next_review_due: nextReview
      },
      effective_from: now,
      authored_by: params.authorProfessionalId,
      approved_by: params.actorId,
      supersedes_id: activeVersion?.id,
      created_at: now
    };

    await CarePlanService.repository.saveVersion(newVersion);

    // Save new goals & interventions
    for (const g of params.goals) {
      g.care_plan_version_id = newVersionId;
      await CarePlanService.repository.saveGoal(g);
    }
    for (const i of params.interventions) {
      i.care_plan_version_id = newVersionId;
      await CarePlanService.repository.saveIntervention(i);
    }

    plan.current_version_id = newVersionId;
    plan.status = CarePlanState.ACTIVE;
    plan.updated_at = now;
    plan.version += 1;
    await CarePlanService.repository.savePlan(plan);

    EventBus.enqueue(
      'care.plan_updated',
      'care_plans',
      plan.id,
      DataClassification.RESTRICTED,
      {
        plan_id: plan.id,
        new_version_id: newVersionId,
        new_version_number: newVersionNumber,
        superseded_version_id: activeVersion?.id,
        rationale: params.changeRationale
      }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: params.actorId,
      action: 'CARE_PLAN.NEW_VERSION_CREATED',
      resource_type: 'care_plan',
      resource_id: plan.id,
      purpose: 'Care Plan Clinical Revision',
      authorization_basis: { relationshipId: plan.care_relationship_id },
      result: 'ALLOWED',
      metadata: {
        newVersion: newVersionNumber,
        rationale: params.changeRationale
      }
    });

    return newVersion;
  }

  public static async pausePlan(planId: string, reason: string, actorId: string): Promise<CarePlan> {
    const plan = await CarePlanService.repository.findPlanById(planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${planId} not found.`);
    }

    validateStateTransition('CarePlanState', plan.status, CarePlanState.PAUSED, plan.id, actorId);

    plan.status = CarePlanState.PAUSED;
    plan.updated_at = new Date().toISOString();
    plan.version += 1;
    await CarePlanService.repository.savePlan(plan);

    EventBus.enqueue(
      'care.plan_paused',
      'care_plans',
      plan.id,
      DataClassification.RESTRICTED,
      { plan_id: plan.id, reason, paused_by: actorId }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: actorId,
      action: 'CARE_PLAN.PAUSED',
      resource_type: 'care_plan',
      resource_id: plan.id,
      purpose: 'Care Strategy Paused',
      authorization_basis: { reason },
      result: 'ALLOWED',
      metadata: { reason }
    });

    return plan;
  }

  public static async completePlan(planId: string, actorId: string): Promise<CarePlan> {
    const plan = await CarePlanService.repository.findPlanById(planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${planId} not found.`);
    }

    validateStateTransition('CarePlanState', plan.status, CarePlanState.COMPLETED, plan.id, actorId);

    const now = new Date().toISOString();
    plan.status = CarePlanState.COMPLETED;
    plan.completed_at = now;
    plan.updated_at = now;
    plan.version += 1;
    await CarePlanService.repository.savePlan(plan);

    EventBus.enqueue(
      'care.plan_completed',
      'care_plans',
      plan.id,
      DataClassification.RESTRICTED,
      { plan_id: plan.id, completed_at: now, completed_by: actorId }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: actorId,
      action: 'CARE_PLAN.COMPLETED',
      resource_type: 'care_plan',
      resource_id: plan.id,
      purpose: 'Care Strategy Goal Attainment',
      authorization_basis: { planId: plan.id },
      result: 'ALLOWED'
    });

    return plan;
  }

  public static async terminatePlan(planId: string, reason: string, actorId: string): Promise<CarePlan> {
    const plan = await CarePlanService.repository.findPlanById(planId);
    if (!plan) {
      throw new NotFoundError(`CarePlan ${planId} not found.`);
    }

    validateStateTransition('CarePlanState', plan.status, CarePlanState.TERMINATED, plan.id, actorId);

    const now = new Date().toISOString();
    plan.status = CarePlanState.TERMINATED;
    plan.terminated_at = now;
    plan.updated_at = now;
    plan.version += 1;
    await CarePlanService.repository.savePlan(plan);

    EventBus.enqueue(
      'care.plan_terminated',
      'care_plans',
      plan.id,
      DataClassification.RESTRICTED,
      { plan_id: plan.id, reason, terminated_at: now, terminated_by: actorId }
    );

    AuditService.record({
      actor_type: 'STAFF',
      actor_id: actorId,
      action: 'CARE_PLAN.TERMINATED',
      resource_type: 'care_plan',
      resource_id: plan.id,
      purpose: 'Care Plan Termination',
      authorization_basis: { reason },
      result: 'ALLOWED',
      metadata: { reason }
    });

    return plan;
  }

  public static async getPlan(id: string): Promise<CarePlan | null> {
    return CarePlanService.repository.findPlanById(id);
  }

  public static async getActiveVersion(planId: string): Promise<CarePlanVersion | null> {
    return CarePlanService.repository.findActiveVersion(planId);
  }

  public static async listPlansForUser(userId: string, status?: CarePlanState): Promise<CarePlan[]> {
    return CarePlanService.repository.findPlansByUserId(userId, status);
  }

  public static async listPlansForProfessional(professionalId: string, status?: CarePlanState): Promise<CarePlan[]> {
    return CarePlanService.repository.findPlansByProfessionalId(professionalId, status);
  }
}
